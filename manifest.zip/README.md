# Netflix-Helper
### Note
This Extension created for personal purposes, then my friends asking for this to give them. 
so I realized some people like me out there who need this. That's why I release this small extension.

### All Features

This extension currently has these features.

| Features | Status |
| ------ | ------ |
| Control volume with mouse | Yes |
| Auto Skip Intro | Yes |
| Assign mouse button for different tasks | Coming soon |
